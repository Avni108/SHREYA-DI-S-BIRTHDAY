var birthday,birthdayImg;
var GameSound;
var Photo,photoImg;

function preload(){
  
birthdayImg = loadImage("HAPPY BIRTHDAY IMAGES.jpg");

GameSound = loadSound("369147__inspectorj__music-box-happy-birthday.wav");
  
photoImg = loadImage("Screenshot_20201201-115311.jpg");   
}

function setup(){
createCanvas(400,400);
  
 GameSound.play(); 
  
birthday = createSprite(200,450,20,20); 
birthday.addImage(birthdayImg);
birthday.scale = 0.3;   
birthday.velocityY = -3; 
  
Photo = createSprite(200,550,20,20);
Photo.addImage(photoImg);
Photo.scale = 0.2;
Photo.velocityY = -2;  
   
}

function draw(){
background("yellow");
  
  if(Photo.y===200){
  Photo.velocityY = 0;         
  }
  
  drawSprites(); 
  
  if(keyDown("space")){
   textSize(20); 
   fill("purple"); 
   text("HAPPY BIRTHDAY SHEU DI!!",70,350); 
  }
}

